<?php

$citas["observaciones"] = "Rimarkoj";
$citas["nombrePaciente"] = "Nomo de Paciento";
$citas["fechaHora"] = "Dato kaj Horo de Komenco";
$citas["observaciones"] = "Rimarkoj";
$citas["hastaFechaHora"] = "Dato kaj Horo de Fino";

$citas["createdAt"] = "Dato de Kreado";
$citas["updateAt"] = "Dato de Modifo";
$citas["add"] = "Aldoni Citon";
$citas["actions"] = "Agoj";
$citas["estado"] = "Stato";
$citas["createEdit"] = "Krei / Redakti Citojn";
$citas["seleccionePaciente"] = "Elektu pacienton";
$citas["title"] = "Citoj";
$citas["subtitle"] = "Listo de Citoj";

$citas["msg_delete"] = "La cito estis forigita.";
$citas["msg_get_fail"] = "La cito ne ekzistas aŭ estis forigita.";

return $citas;