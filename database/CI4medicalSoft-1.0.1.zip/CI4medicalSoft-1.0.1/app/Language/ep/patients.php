<?php

$patients["names"] = "Nomoj";
$patients["lastName"] = "Familiaj Nomoj";
$patients["dni"] = "Identiga Numero"; // "INE" se traduce como "Identiga Numero" en el contexto
$patients["phone"] = "Telefono";
$patients["email"] = "Retpoŝto";
$patients["add"] = "Aldoni Pacienton";
$patients["updateAt"] = "Dato de Modifo";
$patients["actions"] = "Agoj";
$patients["createEdit"] = "Krei / Redakti Pacienton";
$patients["title"] = "Pacientoj";
$patients["subtitle"] = "Listo de Pacientoj";

$patients["msg_delete"] = "La paciento estis sukcese forigita.";
$patients["msg_get_fail"] = "La paciento ne ekzistas aŭ estis forigita.";




return $patients;