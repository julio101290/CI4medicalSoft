<?php

$dashboard["totalCitas"] = "Entuta Citoj";
$dashboard["totalConsultas"] = "Entuta Konsultoj";
$dashboard["totalMedicamentos"] = "Entuta Medikamentoj";
$dashboard["totalPacientes"] = "Entuta Pacientoj";
$dashboard["moreInfo"] = "Pli da Informoj";

return $dashboard;


