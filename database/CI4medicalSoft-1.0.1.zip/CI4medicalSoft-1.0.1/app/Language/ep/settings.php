<?php

return [

    /**
     * Agordoj.
     */
    'settings' => [
        'nameCorporation'  => 'Nomo de la Entrepreno',
        'direction'        => 'Adreso',
        'ID'               => 'Federala Imposta Registra Kodo', // RFC en español se traduce como "Federala Imposta Registra Kodo" en esperanto
        'phone'            => 'Telefono',
        'email'           => 'Retpoŝto',
        'title'           => 'Administri Agordojn',
        'subtitle'        => 'Agordoj',
    ],
];