<?php

$enfermedades["description"] = "Priskribo";

$enfermedades["createdAt"] = "Dato de Kreado";
$enfermedades["updateAt"] = "Dato de Modifo";
$enfermedades["add"] = "Aldoni Malsanon";
$enfermedades["actions"] = "Agoj";
$enfermedades["createEdit"] = "Krei / Redakti Malsanon";
$enfermedades["title"] = "Malsanoj";
$enfermedades["subtitle"] = "Listo de Malsanoj";

$enfermedades["msg_delete"] = "La malsano estis forigita.";
$enfermedades["msg_get_fail"] = "La malsano ne ekzistas aŭ estis forigita.";




return $enfermedades;