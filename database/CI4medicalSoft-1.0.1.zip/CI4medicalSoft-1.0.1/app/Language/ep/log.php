<?php

$log["title"] = "Taglibro";
$log["subtitle"] = "Taglibro de eventoj";
$log["description"] = "priskribo";
$log["user"] = "Uzanto";
$log["date"] = "Dato";

return $log;