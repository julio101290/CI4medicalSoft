<?php

$menu["dashboard"] = "Instrumenttabulo";
$menu["settings"] = "Agordoj";
$menu["perfilUser"] = "Profila Uzanto";
$menu["users"] = "Uzantoj";
$menu["permissions"] = "Rajtoj";
$menu["roles"] = "Roloj";
$menu["menu"] = "Menuo";
$menu["hospitalData"] = "Datumoj de la Hospitalo";
$menu["catalogs"] = "Katalogoj";
$menu["medications"] = "Medikamentoj";


$menu["patiens"] = "Pacientoj";
$menu["diagnoses"] = "Diagnostiko";
$menu["operations"] = "Operacioj";
$menu["medicalAppointments"] = "Medicinaj Renkontiĝoj";
$menu["medicalConsultation"] = "Medicina Konsulto";
$menu["listMedicalConsultations"] = "Listo de Medicinaj Konsultoj";

$menu["log"] = "Taglibro";

return $menu;