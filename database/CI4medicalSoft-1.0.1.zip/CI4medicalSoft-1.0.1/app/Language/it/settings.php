<?php

return [

    /**
     * Configurazioni.
     */
    'settings' => [
        'nameCorporation'  => 'Nome Azienda',
        'direction'        => 'Indirizzo',
        'ID'               => 'Partita IVA', // Equivalente italiano del RFC
        'phone'            => 'Telefono',
        'email'            => 'Indirizzo Email',
        'title'            => 'Gestisci Configurazioni',
        'subtitle'         => 'Configurazioni',
    ],

];