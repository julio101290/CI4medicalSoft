<?php

$menu["dashboard"] = "Cruscotto";
$menu["settings"] = "Impostazioni";
$menu["perfilUser"] = "Profilo Utente";
$menu["users"] = "Utenti";
$menu["permissions"] = "Permessi";
$menu["roles"] = "Ruoli";
$menu["menu"] = "Menu";
$menu["hospitalData"] = "Dati Ospedalieri";
$menu["catalogs"] = "Cataloghi";
$menu["medications"] = "Farmaci";
$menu["patients"] = "Pazienti";
$menu["diagnoses"] = "Diagnosi";
$menu["operations"] = "Interventi";
$menu["medicalAppointments"] = "Appuntamenti Medici";
$menu["medicalConsultation"] = "Visita Medica";
$menu["listMedicalConsultations"] = "Elenco Visite Mediche";
$menu["log"] = "Registro"; // O "Log" si prefieres mantener el término en inglés

return $menu;