<?php

$enfermedades["description"] = "Descrizione";
$enfermedades["createdAt"] = "Data di Creazione";
$enfermedades["updateAt"] = "Data di Modifica";
$enfermedades["add"] = "Aggiungi Malattia";
$enfermedades["actions"] = "Azioni";
$enfermedades["createEdit"] = "Crea / Modifica Malattia";
$enfermedades["title"] = "Malattie";
$enfermedades["subtitle"] = "Elenco delle Malattie";
$enfermedades["msg_delete"] = "La malattia è stata eliminata.";
$enfermedades["msg_get_fail"] = "La malattia non esiste o è stata eliminata.";




return $enfermedades;