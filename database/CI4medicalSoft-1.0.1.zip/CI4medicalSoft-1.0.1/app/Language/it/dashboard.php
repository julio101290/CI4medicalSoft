<?php

$dashboard["totalCitas"] = "Totale Visite";
$dashboard["totalConsultas"] = "Totale Consulenze";
$dashboard["totalMedicamentos"] = "Totale Farmaci";
$dashboard["totalPacientes"] = "Totale Pazienti";
$dashboard["moreInfo"] = "Maggiori Informazioni";

return $dashboard;


