<?php

$bitacora["logDescription"] = "Il record del log è stato salvato con i seguenti dati:";
$bitacora["logUpdate"] = "Il record del log è stato aggiornato con i seguenti dati:";
$bitacora["logDeleted"] = "Il record di log è stato cancellato con i seguenti dati:";
$bitacora["msg_delete"] = "Il record di registro è stato eliminato con successo:";
$bitacora["add"] = "Aggiungi registro";
$bitacora["edit"] = "Modifica registro";
$bitacora["createEdit"] = "Crea/Modifica";
$bitacora["title"] = "Registra amministratore";
$bitacora["subtitle"] = "Elenco registri";
$bitacora["fields"]["descripcion"] = "Descrizione";
$bitacora["fields"]["usuario"] = "Utente";
$bitacora["fields"]["created_at"] = "Creato_a";
$bitacora["fields"]["deleted_at"] = "Eliminato_a";
$bitacora["fields"]["updated_at"] = "Aggiornato_a";
$bitacora["fields"]["actions"] = "Azioni";
$bitacora["msg"]["msg_insert"] = "Record aggiunto con successo.";
$bitacora["msg"]["msg_update"] = "Record modificato con successo.";
$bitacora["msg"]["msg_delete"] = "Record eliminato con successo.";
$bitacora["msg"]["msg_get"] = "Registrazione ottenuta con successo.";
$bitacora["msg"]["msg_get_fail"] = "Record non trovato o eliminato.";

return $bitacora;
