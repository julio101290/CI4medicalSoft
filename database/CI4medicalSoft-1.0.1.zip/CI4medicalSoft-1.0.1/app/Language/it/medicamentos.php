<?php

$medicamentos["description"] = "Descrizione";
$medicamentos["createdAt"] = "Data di Creazione";
$medicamentos["updateAt"] = "Data di Modifica";
$medicamentos["add"] = "Aggiungi Farmaco";
$medicamentos["actions"] = "Azioni";
$medicamentos["createEdit"] = "Crea / Modifica Farmaco";
$medicamentos["title"] = "Farmaci";
$medicamentos["subtitle"] = "Elenco dei Farmaci";
$medicamentos["msg_delete"] = "Il farmaco è stato eliminato.";
$medicamentos["msg_get_fail"] = "Il farmaco non esiste o è stato eliminato.";




return $medicamentos;