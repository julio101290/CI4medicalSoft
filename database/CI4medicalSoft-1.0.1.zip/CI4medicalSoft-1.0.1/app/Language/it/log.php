<?php

$log["title"] = "Registro"; // O "Log" si prefieres mantener el término en inglés
$log["subtitle"] = "Registro degli eventi";
$log["description"] = "descrizione";
$log["user"] = "Utente";
$log["date"] = "Data";


return $log;