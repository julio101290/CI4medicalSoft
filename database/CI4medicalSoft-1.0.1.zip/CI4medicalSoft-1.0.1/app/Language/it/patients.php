<?php

$patients["names"] = "Nomi";
$patients["lastName"] = "Cognomi";
$patients["dni"] = "Codice Fiscale"; // Equivalente italiano del INE
$patients["phone"] = "Telefono";
$patients["email"] = "Indirizzo Email";
$patients["add"] = "Aggiungi Paziente";
$patients["updateAt"] = "Data di Modifica";
$patients["actions"] = "Azioni";
$patients["createEdit"] = "Crea / Modifica Paziente";
$patients["title"] = "Pazienti";
$patients["subtitle"] = "Elenco dei Pazienti";

$patients["msg_delete"] = "Il paziente è stato eliminato correttamente.";
$patients["msg_get_fail"] = "Il paziente non esiste o è stato eliminato.";

return $patients;