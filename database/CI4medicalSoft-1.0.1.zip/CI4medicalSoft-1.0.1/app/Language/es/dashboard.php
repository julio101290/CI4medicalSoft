<?php

$dashboard["totalCitas"] = "Total Citas";
$dashboard["totalConsultas"] = "Total Consultas";
$dashboard["totalMedicamentos"] = "Total Medicamentos";
$dashboard["totalPacientes"] = "Total Pacientes";
$dashboard["moreInfo"] = "Más Información";

return $dashboard;


