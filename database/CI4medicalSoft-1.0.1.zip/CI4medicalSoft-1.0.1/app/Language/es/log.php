<?php

$log["title"] = "Bitacora";
$log["subtitle"] = "Bitacora de eventos";
$log["description"] = "descripcion";
$log["user"] = "Usuario";
$log["date"] = "Fecha";


return $log;