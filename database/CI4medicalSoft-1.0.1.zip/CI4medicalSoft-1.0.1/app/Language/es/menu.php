<?php

$menu["dashboard"] = "Tablero";
$menu["settings"] = "Configuraciones";
$menu["perfilUser"] = "Perfil de Usuario";
$menu["users"] = "Usuarios";
$menu["permissions"] = "Permisos";
$menu["roles"] = "Roles";
$menu["menu"] = "Menu";
$menu["hospitalData"] = "Datos del Hospital";
$menu["catalogs"] = "Catalogos";
$menu["medications"] = "Medicamentos";


$menu["patiens"] = "Pacientes";
$menu["diagnoses"] = "Diagnosticos";
$menu["operations"] = "Operaciones";
$menu["medicalAppointments"] = "Citas Medicas";
$menu["medicalConsultation"] = "Consulta Medica";
$menu["listMedicalConsultations"] = "Listas Consultas Medicas";

$menu["log"] = "Bitacora";

return $menu;