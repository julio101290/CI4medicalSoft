<?php

$enfermedades["description"] = "Descripcion";

$enfermedades["createdAt"] = "Fecha Creación";
$enfermedades["updateAt"] = "Fecha de Modificación";
$enfermedades["add"] = "Agregar Enfermedades";
$enfermedades["actions"] = "Acciones";
$enfermedades["createEdit"] = "Crear  / Editar Enfermedades";
$enfermedades["title"] = "Enfermedades";
$enfermedades["subtitle"] = "Lista de Enfermedades";

$enfermedades["msg_delete"] = "La enfermedad ha sido eliminada .";
$enfermedades["msg_get_fail"] = "La enfermedad no existe o fue eliminada.";





return $enfermedades;