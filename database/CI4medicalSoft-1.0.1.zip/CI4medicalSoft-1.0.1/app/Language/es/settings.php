<?php

return [

   /**
    * Settings.
    */
   'settings' => [
       'nameCorporation'      => 'Nombre Empresa',
       'direction'     => 'Dirección',
       'ID'    => 'RFC',
       'phone'    => 'Telefono',
       'email' => 'Correo Electrónico',
       'title'    => 'Administrar Configuraciones',
       'subtitle' => 'Configuraciones',

   ],


];
