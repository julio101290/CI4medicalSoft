<?php

$log["title"] = "Log";
$log["subtitle"] = "Log of events";
$log["description"] = "Description";
$log["user"] = "User";
$log["date"] = "Date";


return $log;