<?php

$dashboard["totalCitas"] = "Total Dates";
$dashboard["totalConsultas"] = "Total Querys";
$dashboard["totalMedicamentos"] = "Total medicines";
$dashboard["totalPacientes"] = "Total Patients";
$dashboard["moreInfo"] = "More Info";

return $dashboard;


