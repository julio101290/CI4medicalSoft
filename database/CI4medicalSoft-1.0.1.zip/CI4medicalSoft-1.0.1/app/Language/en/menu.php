<?php

$menu["dashboard"] = "Dashboard";
$menu["settings"] = "Settings";
$menu["perfilUser"] = "User Profile";
$menu["users"] = "Users";
$menu["permissions"] = "Permissions";
$menu["roles"] = "Roles";
$menu["menu"] = "Menu";
$menu["hospitalData"] = "Settings Hospital";
$menu["catalogs"] = "Catalogs";
$menu["medications"] = "Medications";

$menu["patiens"] = "Patiens";
$menu["diagnoses"] = "Diagnoses";
$menu["operations"] = "Operations";
$menu["medicalAppointments"] = "Medical Appointments";
$menu["medicalConsultation"] = "Medical Consultation";
$menu["listMedicalConsultations"] = "List Medical Consultation";

$menu["log"] = "Log";


return $menu;