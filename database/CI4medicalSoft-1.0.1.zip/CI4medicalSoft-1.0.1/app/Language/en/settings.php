<?php

return [

   /**
    * Settings.
    */
   'settings' => [
       'nameCorporation'      => 'Name Corporation',
       'title'      => 'Settings',
       'direction'     => 'Direction',
       'ID'    => 'DNI',
       'phone'    => 'Phone',
       'email' => 'EMail',
       'title'    => 'Manage Settings',
       'subtitle' => 'Settings',
       
       'languaje' => 'Languaje',
       'languajeOptionEN' => 'English',
       'languajeOptionES' => 'Spanish',
       'languajeOptionIT' => 'Italian',
       'languajeOptionEP' => 'Esperanto',
       'save' => 'Save',

   ],


];
