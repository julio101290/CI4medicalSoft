<?php

$enfermedades["descrption"] = "Description";

$enfermedades["createdAt"] = "Date Creation";
$enfermedades["updateAt"] = "Date Update";
$enfermedades["add"] = "Add disease";
$enfermedades["actions"] = "Actions";
$enfermedades["createEdit"] = "Create  / Edit disease";
$enfermedades["title"] = "Disease";
$enfermedades["subtitle"] = "List of diseases";

$enfermedades["msg_delete"] = "disease has deleted .";
$enfermedades["msg_get_fail"] = "The disease not exist or has deleted.";





return $enfermedades;